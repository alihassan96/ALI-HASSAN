
<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$pageId		= $_POST['pageId']; 
$pageName		= $_POST['pageName']; 
$pageTitle		= $_POST['pageTitle']; 
$pageContent	= $_POST['pageContent']; 
$pageStatus		= $_POST['pageStatus']; 


$sql = "INSERT INTO tblpages SET pageid='$pageId',
                                     pagename='$pageName', 
									 pagetitle='$pageTitle', 
									 pagecontent='$pageContent',
									 pagestatus='$pageStatus' ";

mysql_select_db('htc');
 
$result = mysqli_query( $conn,$sql);
 
if(!$result)
{
  die('Could not enter data: ' . mysqli_error($conn));
}
 
	header("Location: add.php?status=yes");
 

mysql_close($conn);
?>