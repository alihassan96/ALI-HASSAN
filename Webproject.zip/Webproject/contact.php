<!DOCTYPE html>
<html>
<head>
<script>
funtion myfunction(){
window.confirm("Are you sure? Yo want to submit");
}
</script>
<title>PROJECT</title>
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="new.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" href="/lib/w3.css">

</head>
<body>

<table width="98%" border="0">
  <tr>
  
	
    <td width="100%" align="right"><a href="index.php"  target="_blank"><span style="color:blue">Login</span></a></td>
  </tr>
</table>

<a href="http://www.htc.com/us/" target="_blank"><img src="logo.png"  height="70" width="170" align="left"/></a>
<div id="e">
<a href="http://www.gmail.com" target="_blank"><img src="gmail.png" height="20" width="20"align="right"/></a><a href="http://www.twitter.com" target="_blank"><img src="twit.jpg" height="20" width="20" align="right"/></a><a href="http://www.instagram.com" target="_blank"><img src="insta.jpg" height="20" width="20" align="right"/></a><a href="http://www.facebook.com" target="_blank"><img src="fb.png" height="18" width="20"align="right"/> </a>
</div>
<br>
</br>
<br>
</br>

<div id="a">

&nbsp;&nbsp;<a href="Home.php" style= "text-decoration: none" target="_blank"><font color="white">Home</font></a>
<a href="AboutUs.php" style= "text-decoration: none" target="_blank"><font color="white">AboutUs</font></a>
<a href="Product.php" style= "text-decoration: none" target="_blank"><font color="white">Products</font></a>
<a href="contact.php" style= "text-decoration: none" target="_blank"><font color="white">ContactUs</font></a>
</div > 
<br>
</br>
<br>
</br><br>
</br>


<font  size="25" color="black" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Contact Us</font>
<br>
</br>
<br>
</br>
<br>
</br>
<div id="b">
<table align="left" border="2" cellpadding="20">

<tr>
	<td align="right"><b>Name</b></td>
	<td><input type="text" name="username" placeholder="Enter your name" size="30" required /></td>
	
</tr>

<tr>
	<td align="right"><b>Email</b></td>
	<td><input type="email" name="useremail" placeholder="abc@gmail.com" size="30" required/></td>
</tr>
<tr>
	<td align="right"><b>Mobile No</b></td>
	<td><input type="text" name="mobile" placeholder="Enter your cell number" size="30"/></td>
</tr>
<tr>
	<td align="right"><b>Date Of Birth</b></td>
	<td><input type="datetime-local" name="dob" placeholder="Enter your DOB" size="30"/></td>
</tr>
<tr>
	<td align="right"><b>Remarks</b></td>
	<td>
		<input type="checkbox" name="desire" value="desire" />Good
		<input type="checkbox" name="one" value="one" />Poor
		
		<input type="checkbox" name="windows" value="windows" />Excellent
	</td>
</tr>

<tr>
	<td align="right"><b>Flagship Type</b></td>
	<td>
		<input type="checkbox" name="desire" value="desire" />HTC DESIRE <br></br>
		<input type="checkbox" name="one" value="one" />HTC ONE<br></br>
		
		<input type="checkbox" name="windows" value="windows" />HTC WINDOWS<br></br>
	<input type="checkbox" name="sensation" value="sensation" />HTC SENSATION<br></br>
	</td>
</tr>
<tr>
	<td align="right"><b>Sub-Continent</b></td>

	<td>
	<select name="sub">
		
			<option value="-1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Select</option>
			<option value="master">Asia</option>
			<option value="visa">Africa</option>
			<option value="master">North America</option>
			<option value="visa">South America</option>
			<option value="master">Antarctica</option>
			<option value="master">Europe</option>
			<option value="visa">Australia</option>
		</select>
	</td>
</tr>
<tr>
	<td align="right"><b>Payment</b></td>
	<td>
		<input type="checkbox" name="cash" value="Cash" />PayPal
		<input type="checkbox" name="credit" value="Credit Card" />Credit Card
		<select name="bank">
			<option value="-1">Select Card</option>
			<option value="master">Master</option>
			<option value="visa">Visa</option>
		</select>
	</td>
</tr>
<tr align="center">
	<td colspan="2">
		<input type="submit" onClick="myfunction()" name="submit" value="Submit" />
	</td>
</tr>
<div id="ef">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d525.2420515727654!2d74.31991057462074!3d31.55394085146724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391904ae8439c08b%3A0x783deba33ccf9f0b!2sHTC!5e0!3m2!1sen!2s!4v1488180392615" align="right" width="600" height="400" frameborder="5"  style="border:0" allowfullscreen></iframe>
</div>

</table>

</form>
</div>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br><br>
</br>

<footer  class="w3-container w3-light-green  w3-padding-5 w3-center w3-opacity w3-margin-bottom">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-1">
    <a href="https://www.facebook.com/HTC/"><i class="fa fa-facebook-official w3-hover-text-indigo"></i></a>
     <a href="https://twitter.com/htc?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fa fa-instagram w3-hover-text-purple"></i></a>
     <a href="http://www.downloadsnapchat.org/snapchat-for-htc"><i class="fa fa-snapchat w3-hover-text-yellow"></i></a>
     <a href="https://www.instagram.com/htc/?hl=en"><i class="fa fa-twitter w3-hover-text-light-blue"></i></a>
  </div>
  <marquee> © 2011-2017 HTC Corporation</marquee>
  <p>Powered by <a href="http://www.htc.com/us/" target="_blank" class="w3-hover-text-black">HTC</a></p>


</body>
</html>