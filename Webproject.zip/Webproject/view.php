<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	session_start();
		
	
		if ( !isset ($_SESSION["username"]))
		{
		header("Location: index.php");
		exit( );
		}
		
?> 		
?>
<!DOCTYPE html>
<html>
<head>
<title>PROJECT</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body bgcolor= "white">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" href="/lib/w3.css">
</head>
<body>
	<table width="100%" border="0">
  <tr>
  

    <td width="36%" align="right">Welcome <?=$_SESSION['username']?> | <a href="logout.php" target="_blank">Logout</a></td>
  </tr>
</table>
<br>
</br>
 <div id="a">

&nbsp;&nbsp;<a href="Home.php" style= "text-decoration: none" target="_blank"><font color="white">Home</font></a>
<a href="addproducts.php" style= "text-decoration: none" target="_blank"><font color="white">Products</font></a>
<a href="add.php" style= "text-decoration: none" target="_blank"><font color="white">Add</font></a>
<a href="view.php" style= "text-decoration: none" target="_blank"><font color="white">View</font></a>

</div > 

	</td>
  </tr>
  <tr>
    <td height="463" align="center" valign="middle">
			<table> 
			<tr>
			<td height="33" colspan="2" style="font-weight:bold" ><?php
											if($_GET)
											{
												if($_GET['status']=='updated') echo "<span style='color:green'>Record Successfully Updated!</span>";
												elseif($_GET['status']=='deleted') echo "<span style='color:green'>Record Successfully Deleted!</span>"; 
												else "<span style='color:red'>Sorry There is some issue, Try Again</span>"; 
											}?></td>
			</tr>
			</table>
			
			<table width="100%" border="0">
			  <tr>
	            <td style="border-bottom:1px solid" width="4%"><strong>Id</strong></td>
				<td style="border-bottom:1px solid" width="10%"><strong>Name</strong></td>
				<td style="border-bottom:1px solid" width="6%"><strong>Price</strong></td>
			
				<td style="border-bottom:1px solid" width="10%"><strong>Instock</strong></td>
				<td style="border-bottom:1px solid" width="10%"><strong>Discount</strong></td>
				<td style="border-bottom:1px solid" width="10%"><strong>Details</strong></td>
				
					<td style="border-bottom:1px solid" width="10%"><strong>Size</strong></td>
				
				<td style="border-bottom:1px solid" width="10%"><strong>Picture</strong></td>
				<td style="border-bottom:1px solid" width="10%"><strong>Operations</strong></td>
			  </tr>
			  

	<?php	
	
		$sql="SELECT * FROM tblproducts";
		
		$result=mysqli_query($conn,$sql);
		$count=mysqli_num_rows($result);
	
		if ($count > 0) 
		{
			while($row = mysqli_fetch_array($result))
			{
			?>
			<tr style="border-bottom:1px solid">
	        <td style="border-bottom:1px solid"><?=$row["productId"]?></td>
			<td style="border-bottom:1px solid"><?=$row["productname"]?></td>
			<td style="border-bottom:1px solid"><?=$row["productprice"]?></td>
			
			<td style="border-bottom:1px solid"><?=$row["productinstock"]?></td>
				<td style="border-bottom:1px solid"><?=$row["productdiscount"]?></td>
				<td style="border-bottom:1px solid"><?=$row["productdetails"]?></td>
					<td style="border-bottom:1px solid"><?=$row["productsizes"]?></td>
	
				<td style="border-bottom:1px solid"><?=$row["productpic"]?></td>
			<td style="border-bottom:1px solid">
			<a href="edit.php?pId=<?=$row["productId"]?>">Edit</a> 
			<a href="delete.php?pId=<?=$row["productId"]?>">Delete</a></td>
		  </tr>
			<?php
			}
		} 
	?>
	
			
			</table>
	</td>
  </tr>
</table>
</form>
	
	</td>
  </tr>
  <tr>
<br>
</br>
<br>
</br><br>
</br>
<br>
</br><br>
</br>
<br>
</br><br>
</br>
<br>
</br><br>
</br>
<br>
</br><br>
</br>
<br>
</br><br>
</br>
<br>
</br>
<footer  class="w3-container w3-light-green  w3-padding-5 w3-center w3-opacity w3-margin-bottom">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-1">
    <a href="https://www.facebook.com/HTC/"><i class="fa fa-facebook-official w3-hover-text-indigo"></i></a>
     <a href="https://twitter.com/htc?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fa fa-instagram w3-hover-text-purple"></i></a>
     <a href="http://www.downloadsnapchat.org/snapchat-for-htc"><i class="fa fa-snapchat w3-hover-text-yellow"></i></a>
     <a href="https://www.instagram.com/htc/?hl=en"><i class="fa fa-twitter w3-hover-text-light-blue"></i></a>
  </div>
  <marquee> © 2011-2017 HTC Corporation</marquee>
  <p>Powered by <a href="http://www.htc.com/us/" target="_blank" class="w3-hover-text-black">HTC</a></p>
</body>
</html>
