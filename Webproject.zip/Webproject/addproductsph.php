
<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$productName = $_POST['productname']; 
$productPrice = $_POST['productprice']; 
$productDiscount = $_POST['productdiscount']; 
$productSizes = $_POST['productsizes']; 
$productInstock = $_POST['productinstock']; 
$productDetails = $_POST['productdetails'];
$productPic = $_POST['productpic']; 




$sql = "INSERT INTO tblproducts SET 
									productname='$productName', 
									productprice='$productPrice',
							       
                                    productinstock	='$productInstock',								
                                    productdiscount='$productDiscount',
									productdetails='$productDetails',	
                                    productsizes='$productSizes',
																	
									productpic='$productPic'";									


																		
mysql_select_db('htc');
 
$result = mysqli_query( $conn,$sql);
 
if(!$result)
{
  die('Could not enter data: ' . mysqli_error($conn));
}
 
	header("Location: addproducts.php?status=yes");
 

mysql_close($conn);
?>