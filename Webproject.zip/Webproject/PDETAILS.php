<?php 
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


		
		
			?>
<!DOCTYPE html>
<html>
<head>

<title>PROJECT</title>
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="new.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" href="/lib/w3.css">
</head>
<body>
<table width="98%" border="0">
  <tr>
  
	
    <td width="100%" align="right"><a href="index.php"  target="_blank"><span style="color:blue">Login</span></a></td>
  </tr>
</table>

<a href="http://www.htc.com/us/" target="_blank"><img src="logo.png"  height="70" width="170" align="left"/></a>
<div id="e">
<a href="http://www.gmail.com" target="_blank"><img src="gmail.png" height="23" width="20"align="right"/></a><a href="http://www.twitter.com" target="_blank"><img src="twit.jpg" height="20" width="20" align="right"/></a><a href="http://www.instagram.com" target="_blank"><img src="insta.jpg" height="20" width="20" align="right"/></a><a href="http://www.facebook.com" target="_blank"><img src="fb.png" height="18" width="20"align="right"/> </a>
</div>
<br>
</br>
<br>
</br>

<div id="a">

&nbsp;&nbsp;<a href="Home.php" style= "text-decoration: none" target="_blank"><font color="white">Home</font></a>
<a href="AboutUs.php" style= "text-decoration: none" target="_blank"><font color="white">AboutUs</font></a>
<a href="Product.php" style= "text-decoration: none" target="_blank"><font color="white">Products</font></a>
<a href="contact.php" style= "text-decoration: none" target="_blank"><font color="white">ContactUs</font></a>
</div > 

</br>
<br>
</br>
<br>
</br>
<br>
</br>


<br>
</br><br>
</br>
<div id="ab1">
<h1 align="center">HTC U ULTRA</h1>
<img src="ultra.png" height="250" width="350" align="right"/></a>
<li>Display. 5.70-inch.</li>
<li>Processor. 2.15GHz quad-core.</li>
<li>Front Camera. 16-megapixel.</li>
<li>Resolution. 1440x2560 pixels.</li>
<li>RAM. 4GB.</li>
<li>OS. Android 7.0.</li>
<li>Storage. 64GB.</li>
<li>Rear Camera. 12-Ultrapixel.</li>
<p style="font-family:courier;" align="center"><b><u>Price:86,500PKR.  </b></u><p>
</div>

<br>
</br>
<div id="ab1">
<h1 align="center">HTC10</h1>
<img src="10.jpg" height="260" width="360" align="right"/></a>
<li>Type. Super LCD5 capacitive touchscreen, 16M colors</li>
<li>Size. 5.2 inches (~71.1% screen-to-body ratio)</li>
<li>Resolution.	1440 x 2560 pixels (~565 ppi pixel density)</li>
<li>Camera. 12MP(Front. 5MP) </li>
<li>Multitouch.	Yes</li>
<li>Protection.	Corning Gorilla Glass 3</li>
<li>Storage. 32GB</li>
<li>RAM 4GB</li>
<p style="font-family:courier;" align="center"><b><u>Price:94,000PKR.  </b></u><p>
</div>

<br>
</br>
<div id="ab1">
<h1 align="center">HTC One A9</h1>
<img src="a9.jpg" height="270" width="300" align="right"/></a>
<li>Multitouch	Yes</li>
<li>Protection	Corning Gorilla Glass 3</li>
 	
<li>OS	Android OS, v6.0 (Marshmallow), upgradable to v7.0 (Nougat)</li>
<li>Chipset	Qualcomm MSM8952 Snapdragon 617</li>
<li>CPU	Octa-core (4x1.5 GHz Cortex-A53 & 4x1.2 GHz Cortex-A53)</li>
<li>Card slot	microSD, up to 256 GB (dedicated slot)</li>
<li>Internal	16 GB, 2 GB RAM, 32 GB, 3 GB RAM</li>
<li>Primary	13 MP, f/2.0, autofocus</li>

<li>Secondary	4 MP, f/2.0, 27mm, 1/3" sensor size, 2µm pixel size</li>
<p style="font-family:courier;" align="center"><b><u>Price:78,000PKR.  </b></u><p>
</div>

<br>
</br>
<div id="ab1">
<h1 align="center">HTC One M9</h1>
<img src="m9.png" height="260" width="280" align="right"/></a>
<li>Android 5.0 Lollipop with Sense 7.0.</li>
<li>5in Full HD screen (1080x1920)</li>
<li>Qualcomm Snapdragon 810 processor, 64-bit, octa-core.</li>
<li>3 GB RAM.</li>
<li>32 GB storage, microSD card slot (up to 128 GB), 100 GB Dropbox cloud storage.</li>
<li>20 Mp rear camera.</li>
<li>4 Mp UltraPixel front camera.</li>
<li>dual-band 11ac Wi-Fi</li>
<p style="font-family:courier;" align="center"><b><u>Price:60,000PKR.  </b></u><p>
</div>


<br>
</br>
<div id="ab1">
<h1 align="center">HTC Nexus 9(Tablet)</h1>
<img src="nexus.jpg" height="300" width="300" align="right"/></a>
<li>Type LCD capacitive touchscreen, 16M colors</li>
<li>Size 8.9 inches (~73.5% screen-to-body ratio)</li>
<li>Resolution	1536 x 2048 pixels (~281 ppi pixel density)</li>
<li>Multitouch	Yes</li>
<li>Protection Corning Gorilla Glass 3</li>
<li>OS Android OS, v5.0 (Lollipop), upgradable to v7.1.1 (Nougat)</li>
<li>CPU	Dual-core 2.3 GHz Denver</li>
<li>Internal 16 GB (Wi-Fi)/ 32 GB (LTE), 2 GB RAM</li>
<li>Primary	8 MP, autofocus, LED flash, check quality</li>
<li>Secondary	1.6 MP, 720p</li>
<p style="font-family:courier;" align="center"><b><u>Price:50,000PKR.  </b></u><p>
</div>

<br>
</br>
<div id="ab1">
<h1 align="center">HTC Bolt</h1>
<img src="bolt.jpg" height="290" width="350" align="right"/></a>

<li>Operating System	Android 7.0 Nougat</li>
<li>Display	5.5-inch IPS Super LCD 3</li>
<li>Gorilla Glass 5</li>
<li>Processor	Qualcomm Snapdragon 810</li>
<li>Octa-core 2 Ghz</li>
<li>Storage	32GB</li>
<li>RAM	3GB</li>
<li>Rear Camera	16MP, f/2.0, OIS</li>
<li>Front Camera 8MP 1080p video</li>
<p style="font-family:courier;" align="center"><b><u>Price:85,000PKR.  </b></u><p>
</div>
<br>
</br>
<?php
$sql="SELECT * FROM tblproducts";
		
$result=mysqli_query($conn,$sql);
		$count=mysqli_num_rows($result);
	
		if ($count > 0) 
		{
			while($row = mysqli_fetch_array($result))
			{
			?>
			
			
			<div id="ab1">
			<h1 align="center"><?=$row["productname"]?></h1>
<img src="<?=$row["productpic"]?>" height="100" width="100" align="right"/></a>
	       <li><?=$row["productdetails"]?></li>
			<p style="font-family:courier;" align="center"><b><u><?=$row["productprice"]?> </b></u><p>
			
			
	
	</div>
			<?php
			}
		} 
	?>



<br>
</br>
<br>
</br><br>
</br>
<br>
</br>
<br>
</br>

<footer  class="w3-container w3-light-green  w3-padding-5 w3-center w3-opacity w3-margin-bottom">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-1">
    <a href="https://www.facebook.com/HTC/"><i class="fa fa-facebook-official w3-hover-text-indigo"></i></a>
     <a href="https://twitter.com/htc?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fa fa-instagram w3-hover-text-purple"></i></a>
     <a href="http://www.downloadsnapchat.org/snapchat-for-htc"><i class="fa fa-snapchat w3-hover-text-yellow"></i></a>
     <a href="https://www.instagram.com/htc/?hl=en"><i class="fa fa-twitter w3-hover-text-light-blue"></i></a>
  </div>
  <marquee> © 2011-2017 HTC Corporation</marquee>
  <p>Powered by <a href="http://www.htc.com/us/" target="_blank" class="w3-hover-text-black">HTC</a></p>



</body>
</html>