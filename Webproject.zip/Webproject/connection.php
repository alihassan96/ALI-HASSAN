<?php
	// 1. create a database connection
	$connection = mysql_connect("localhost","root","");
	if(!$connection){
		die("database connection failed" . mysql_error());
	}
	
	// 2. select a database
	$db_select = mysql_select_db("htc",$connection);
	if(!$db_select){
		die("database selection failed" . mysql_error());
	}
?> 
