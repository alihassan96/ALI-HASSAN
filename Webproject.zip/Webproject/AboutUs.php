<!DOCTYPE html>
<html>
<head>

<title>PROJECT</title>
<link rel="stylesheet" type="text/css" href="new.css">

<link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="new.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="new.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">
<link rel="stylesheet" href="/lib/w3.css">
</head>
<body>
<table width="98%" border="0">
  <tr>
  
	
    <td width="100%" align="right"><a href="index.php"  target="_blank"><span style="color:blue">Login</span></a></td>
  </tr>
</table>

<a href="http://www.htc.com/us/" target="_blank"><img src="logo.png"  height="70" width="170" align="left"/></a>
<div id="e">
<a href="http://www.gmail.com" target="_blank"><img src="gmail.png" height="23" width="20"align="right"/></a><a href="http://www.twitter.com" target="_blank"><img src="twit.jpg" height="20" width="20" align="right"/></a><a href="http://www.instagram.com" target="_blank"><img src="insta.jpg" height="20" width="20" align="right"/></a><a href="http://www.facebook.com" target="_blank"><img src="fb.png" height="18" width="20"align="right"/> </a>
</div>
<br>
</br>
<br>
</br>

<div id="a">

&nbsp;&nbsp;<a href="Home.php" style= "text-decoration: none" target="_blank"><font color="white">Home</font></a>
<a href="AboutUs.php" style= "text-decoration: none" target="_blank"><font color="white">AboutUs</font></a>
<a href="Product.php" style= "text-decoration: none" target="_blank"><font color="white">Products</font></a>
<a href="contact.php" style= "text-decoration: none" target="_blank"><font color="white">ContactUs</font></a>
</div > 
<div id="a1">
<img  src="logo.png" width="500" align="center" />
</div>

<div id="a1">
<font color="black">&nbsp;&nbsp;Company Overview</font>
</div>
<br>
</br>
<br>
</br><br>
</br><br>
</br>
<div id="abc">

<p><font size="5">
<b>HTC brings brilliance to life through leading innovation in smart mobile device and experience design. Beginning with a vision to put a personal computer in the palm of our customers' hands, we have led the way in the evolution from palm PC to smartphone.

The Pursuit of Brilliance is at the heart of everything we do,inspiring best-in-class design and game-changing mobile experiences for consumers around the world.At HTC, the Pursuit of Brilliance is the impulse create,to venture into the unknown with an unwavering dedication to bring innovative design to life. It pushes us everyday to re-imagine new ways to connect the world, our consumers, and their pursuits in ways never before thought possible.</b>
</font>

</p>
</div>


<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>


<footer  class="w3-container w3-light-green  w3-padding-5 w3-center w3-opacity w3-margin-bottom">
  <h5>Find Us On</h5>
  <div class="w3-xlarge w3-padding-1">
    <a href="https://www.facebook.com/HTC/"><i class="fa fa-facebook-official w3-hover-text-indigo"></i></a>
     <a href="https://twitter.com/htc?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fa fa-instagram w3-hover-text-purple"></i></a>
     <a href="http://www.downloadsnapchat.org/snapchat-for-htc"><i class="fa fa-snapchat w3-hover-text-yellow"></i></a>
     <a href="https://www.instagram.com/htc/?hl=en"><i class="fa fa-twitter w3-hover-text-light-blue"></i></a>
  </div>
  <marquee> © 2011-2017 HTC Corporation</marquee>
  <p>Powered by <a href="http://www.htc.com/us/" target="_blank" class="w3-hover-text-black">HTC</a></p>







</body>
</html>