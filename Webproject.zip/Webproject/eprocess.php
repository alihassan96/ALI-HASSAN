<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

 $productId = $_POST['productId']; 
 $productName = $_POST['productName']; 
$productPrice = $_POST['productPrice']; 

$productDiscount = $_POST['productDiscount']; 
$productPic = $_POST['produtdetails']; 

$productInstock = $_POST['productInstock']; 


$productPic = $_POST['productPic']; 


$sql = "Update tblproducts SET  
						            productname='$productName', 
									productprice='$productPrice',
							
                                    productinstock	='$productInstock',								
                                    productdiscount='$productDiscount',
                                   	productpic='$productdetails' 								
									productpic='$productPic' 
									where productId='$productId'";

//mysql_select_db('test_db');
 
$result = mysqli_query( $conn,$sql);
 
if(!$result)
{
  die('Could not enter data: ' . mysqli_error());
}
 
	header("Location: view.php?status=updated");
 

mysql_close($conn);
?>