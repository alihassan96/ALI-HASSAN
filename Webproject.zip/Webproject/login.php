
<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb = "htc";

// Create connection
$conn = new mysqli($servername, $username, $password ,$mydb);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";





$myusername=$_POST['myusername']; 
$mypassword=$_POST['mypassword']; 

		// To protect MySQL injection (more detail about MySQL injection)
		$encriptedPass=md5($mypassword);
		
		$sql="SELECT * FROM tblusers WHERE username='$myusername' and userpassword='$mypassword'";
		
		$result=mysqli_query($conn,$sql);
		
		// Mysql_num_row is counting table row
		$count=mysqli_num_rows($result);
		echo "$count";
		
		// If result matched $myuseqrname and $mypassword, table row must be 1 row
		if($count==1)
		{
	
		session_start();
		
		$_SESSION["username"]="$myusername";
		$_SESSION["password"]="$encriptedPass";
		if  ( ($_SESSION["username"]))
		{
		header("Location: welcome.php");
		exit( );
		}
		else 
		{
		echo "Wrong Username or Password";
		}

		}
?>
